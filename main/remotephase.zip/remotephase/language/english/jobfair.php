<?
define('HEADING_TITLE','Job Fair');
define('TEXT_DISPLAY_NUMBER_OF_JOBFAIRS', 'Displaying <b>%d</b> to <b>%d</b> (of <b>%d</b> Job Fairs)');
define('INFO_TEXT_NEWSLETTER','Home');
define('INFO_TEXT_EMAIL','Send to Friend');
define('INFO_TEXT_PRINT','Print this Job Fair');
define('INFO_TEXT_MORE','More');
define('INFO_TEXT_SORRY_NO_JOBFAIR','Sorry, no JobFair exists.');
define('INFO_TEXT_BY','By');
define('INFO_TEXT_LATEST_JOBFAIR','Latest Job Fairs');
define('INFO_TEXT_PRINT_JOBFAIR','Print Job Fair');
define('INFO_TEXT_SORRY_NO_FILE_EXIST','Sorry, no file exist.');
define('HEADING_TITLE_ALL_FAIR','All Fairs');
define('SEE_DOCUMENT','See the Document');
define('INFO_TITLE_DOCUMENT','See the gazette');
define('INFO_TITLE_DOCUMENT_DESC1','Watch and download the event gazette');
define('INFO_TITLE_DOCUMENT_DESC2','Watch and download the event gazette. Looking for a job? A training ? Or even an activity under independent status? Or simply practical and concrete information in your journey back to work?');
define('INFO_TEXT_SORT_BY','Sort By');
define('INFO_TEXT_START_ASC','Begin Date(asc)');
define('INFO_TEXT_START_DESC','Begin Date(desc)');
define('INFO_TEXT_NAME_ASC','Title(asc)');
define('INFO_TEXT_NAME_DESC','Title(desc)');
define('INFO_TEXT_END_ASC','End date(asc)');
define('INFO_TEXT_END_DESC','End Date(desc)');
define('ALL_JOBS','View All Jobs');
?>