<?

define('HEADING_TITLE','References');
define('TABLE_HEADING_EDIT','Edit');
define('TABLE_HEADING_DELETE','Delete');

define('INFO_TEXT_DELETE','Delete');

define('REQUIRED_INFO','* Required information');
define('SECTION_ACCOUNT_RESUME_NAME','Resume name');

define('INFO_TEXT_RESUME_NAME','Resume name :');

define('MESSAGE_SUCCESS_INSERTED','Success : Record successfully Inserted.');
define('MESSAGE_SUCCESS_UPDATED','Success : Record successfully Updated.');
define('MESSAGE_SUCCESS_DELETE','Success : Record successfully Deleted.');
define('IMAGE_UPDATE','Update');
define('IMAGE_SAVE_NEXT','Save & goto next step');
define('IMAGE_SAVE_ADD_NEW','Save & Add New');
define('IMAGE_NEXT','Goto next page >>');
define('IMAGE_HELP','Help');
//////// Reference start////////
define('TABLE_HEADING_NAME','Name');
define('TABLE_HEADING_COMPANY_NAME','Company Name');
define('TABLE_HEADING_EMAIL_ADDRESS','Email Address');

define('SECTION_REFERENCE_DETAILS','List of References');
define('ENTER_NAME_ERROR','please enter the name');


define('INFO_TEXT_NAME','Name :');
define('INFO_TEXT_COMPANY_NAME','Company Name :');
define('INFO_TEXT_REF_COUNTRY','Country :');
define('INFO_TEXT_POSITION_TITLE','Position Title :');
define('INFO_TEXT_CONTACT_NO','Contact No :');
define('INFO_TEXT_EMAIL_ADDRESS','Email Address :');
define('INFO_TEXT_RELATIONSHIP','Relationship :');
define('TEXT_PLEASE_SELECT','Select');
define('INFO_TEXT_PLEASE_SELECT_COUNTRY','Please select a country');
define('INFO_TEXT_YEAR','Year');
define('INFO_TEXT_MONTH','Month');
define('INFO_TEXT_HOUR','Hour');
define('INFO_TEXT_PLEASE_SELECT','Please select');
define('INFO_TEXT_RESUME_NAME','Resume name :');
define('INFO_TEXT_OBJECTIVE','Objective');
define('INFO_TEXT_TARGET_JOB','Target Job');
define('INFO_TEXT_TOTAL_WORK_EXP','Total Work Experience');
define('INFO_TEXT_YOUR_WORK_EXPERIENCE','Your Work Experience');
define('INFO_TEXT_LIST_OF_REFERENCES','List of References');
define('INFO_TEXT_EDUCATION_DETAILS','Education Details');
define('INFO_TEXT_YOUR_SKILLS','Your Skills');
define('INFO_TEXT_LANGUAGES','Languages');
define('INFO_TEXT_RESUME','Resume');
define('INFO_TEXT_PERSONAL_PROFILE','Personal Profile');
define('INFO_TEXT_EXPERIENCE','Experience');
define('INFO_TEXT_LEFT_RESUME','General');
define('INFO_TEXT_LEFT_EXPERIENCE','Experience');
define('INFO_TEXT_LEFT_EDUCATION','Education');
define('INFO_TEXT_LEFT_SKILLS','Skills');
define('INFO_TEXT_LEFT_UPLOAD','Upload');
define('INFO_TEXT_LEFT_REFERENCE','References');
define('INFO_TEXT_LEFT_VIEW_RESUME','View Resume');
define('INFO_SKIP_THIS_STEP','Skip');
?>