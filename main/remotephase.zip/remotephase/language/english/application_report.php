<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik#**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/

define('HEADING_TITLE', 'Reports');
define('HEADING_TITLE_PIPELINE', 'Applicant Pipeline');
define('HEADING_TITLE_ROUNDWISE','Round Wise Reports');

define('TABLE_HEADING_TITLE', 'Date wise Applied Applicants');
define('TABLE_HEADING_TITLE1', 'Applicant Round/Status Report' );
define('TABLE_HEADING_DATE', 'Date');
define('TABLE_HEADING_APPLICATION', 'Application Inserted');
define('TABLE_HEADING_SELECTED_APPLICATION', 'Application Selected');
define('TABLE_HEADING_ROUND_STATUS','Round\Status -->');
define('TABLE_HEADING_NEW','New');
define('TABLE_HEADING_TOTAL','Total');
define('TABLE_HEADING_PROCESS','In Process');
define('TABLE_HEADING_REJECT','Rejected');
define('TABLE_HEADING_SELECT','Approved');
define('TABLE_HEADING_WAITING','Waiting');
define('INFO_TEXT_BACK', 'Back');

define('INFO_TEXT_ALL_APPLICANT','All Applicants');
define('INFO_TEXT_SELECTED_APPLICANT','Selected Applicants');
define('INFO_TEXT_SEARCH_APPLICANT','Search Applicant');
define('INFO_TEXT_JOB_DETAIL','Job Detail');
define('INFO_TEXT_ADD_APPLICANT','Add/Import Applicant');
define('INFO_TEXT_REPORT_PIPELINE','Applicant Pipeline');
define('INFO_TEXT_REPORT_ROUNDWISE','Roundwise Report');
define('INFO_TEXT_REPORT_ROUNDWISE_SUMMARY','Roundwise Status Report');
define('INFO_TEXT_VIEW_DATE_REPORT',' Date wise Applied Applicants');

define('INFO_TEXT_JOB_LISTING', 'Job Listing');
define('INFO_TEXT_APPLICATION', 'Application');
define('INFO_TEST_HEADER_SUMMERY', 'Summery');

define('INFO_TEXT_FROM_DATE', 'From :');
define('INFO_TEXT_TO_DATE', 'To :');
define('IMAGE_GO', 'Go');
define('INFO_TEXT_ROUND', 'Round');
define('INFO_TEXT_SELECTED', 'Selected');
define('INFO_TEXT_JOINED', 'Joined');
define('INFO_TEXT_DECLINED', 'Declined');
define('INFO_TEXT_TOTAL', 'Total');

?>