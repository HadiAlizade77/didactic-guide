<?
define('HEADING_TITLE','Advertise with Us');
define('INFO_TEXT_CONTENT','Under Construction');
?>