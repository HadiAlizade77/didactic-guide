<?
define('HEADING_TITLE','Company details');
define('ERROR_COMPANY_DETAILS_NOT_EXIST','Error : Sorry, company details does not exist. If problem persists please contact the system administrator.');
define('IMAGE_BACK','Back');
define('INFO_TEXT_LATEST_POSITIONS','Latest positions');
define('INFO_TEXT_JOBS','List of Jobs');
//*********************************************************************//
define('INFO_TEXT_CURRENT_RATING','Current rating  : ');
define('INFO_TEXT_CURRENT_RATE_IT','Rate it  ');
define('INFO_TEXT_CURRENT_RATE_STRING','');
define('SECTION_RATE_COMPANY','Rate Company');
define('INFO_TEXT_NOT_RATED','Not Rated');
define('MESSAGE_SUCCESS_RATED','Recruiter successfully rated.');
?>