<?
define('HEADING_TITLE','Video Resume');

?>