<?
define('HEADING_TITLE','Contact Form');
define('INFO_TEXT_FULL_NAME','Full name : ');
define('INFO_TEXT_EMAIL_ADDRESS','E-Mail address : ');
define('INFO_TEXT_SUBJECT','Subject : ');
define('INFO_TEXT_MESSAGE','Message : ');
define('SUCCESS_EMAIL_SENT','Your message successfully sent.');
define('IMAGE_SEND','Send');
define('FIRST_PARAGRAPH','<p>Please use this form to submit a question for our staff to review. We will respond to your question/comment as soon as possible.</p>');
define('YOUR_NAME_ERROR','Please enter your name.');
define('YOUR_EMAIL_ADDRESS_ERROR','Please enter your e-mail address.');
define('EMAIL_SUBJECT_ERROR','Please enter e-mail subject.');
define('EMAIL_MESSAGE_ERROR','Please enter e-mail message.');
define('INFO_TEXT_SECURITY_CODE','Security Code :');
define('INFO_TEXT_TYPE_CODE','Type the code shown');
define('ERROR_SECURITY_CODE','Error: Invalid Security Code .');
?>