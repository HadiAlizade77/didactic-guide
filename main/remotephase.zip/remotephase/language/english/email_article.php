<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Email to your friend');
define('SUCCESS_EMAIL_SENT','Your message successfully sent to your friend.');
define('INFO_TEXT_FROM_NAME','Your full name : ');
define('INFO_TEXT_FROM_EMAIL_ADDRESS','Your email-address : ');
define('INFO_TEXT_TO_NAME','Your friend\'s full name : ');
define('INFO_TEXT_TO_EMAIL_ADDRESS','Your friend\'s email-address : ');
define('INFO_TEXT_SUBJECT','Article Title : ');
define('INFO_TEXT_URL','URL : ');
define('IMAGE_SEND','Send');
define('NO_ARTICLE','Sorry, there is no article to send');
define('INFO_TEXT_NEWSLETTER','Home');
define('INFO_TEXT_CATEGORY','Categories');
define('INFO_TEXT_CLICK_HERE','Click here');
define('INFO_TEXT_HI','Hi');
define('INFO_TEXT_YOUR_FRIEND','Your friend');
define('INFO_TEXT_INTERESTING_ARTICLE','has sent a an interesting Article for you.Would you care to read it?');
define('INFO_TEXT_EMAIL_ADDRESS','E-mail Address is');
define('INFO_TEXT_MESSAGE_AS','Message is as follows...');
define('INFO_TEXT_ARTICLE','Article');
define('INFO_TEXT_ARTICLE_FROM','Article from');
define('INFO_TEXT_HOME','Home');
define('INFO_TEXT_Q_A','Q & A');
define('YOUR_NAME_ERROR','Please enter your name.');
define('YOUR_EMAIL_ADDRESS_ERROR','Please enter your e-mail address name.');
define('YOUR_FRIEND_NAME_ERROR','Please enter your friend name.');
define('YOUR_FRIEND_EMAIL_ADDRESS_ERROR','Please enter your friend e-mail address name.');
?>