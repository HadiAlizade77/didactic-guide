<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Job Seeker Login here');

define('INFO_TEXT_EMAIL_ADDRESS','E-Mail Address :');
define('INFO_TEXT_PASSWORD','Password :');

define('IMAGE_CONFIRM','Confirm');
define('AUTO_LOGIN','Enable Auto Log in');
define('SORRY_LOGIN_MATCH','Sorry your Email-address or password seems to be incorrect. Please try again.');
define('FACEBOOK_USER_RECRUITER_ERROE','Sorry your email-address Registe as recruiter therefore not add as jobseeker.');
define('INFO_TEXT_ALREADY_MEMBER','Already a Member?');
define('INFO_TEXT_LOGIN','Login');
define('INFO_TEXT_1','Search jobs by location, category & company');
define('INFO_TEXT_2','Submit resume to any employer with one click');
define('INFO_TEXT_3','View how often employers viewed your resume');
define('INFO_TEXT_4','Get Mail from employer regarding Interview');
define('INFO_TEXT_CLICK_HERE','Click here');
define('INFO_TEXT_FORGOT_PASSWORD','Forgot Password');
define('INFO_TEXT_NEW_USER','New User');
define('INFO_TEXT_REGISTER_NOW','Register Now !');
?>