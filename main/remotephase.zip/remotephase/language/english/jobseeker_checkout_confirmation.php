<?
define('HEADING_TITLE', 'Order Confirmation');
define('HEADING_TITLE1', 'Purchase order');

define('HEADING_DELIVERY_ADDRESS', 'Delivery Address');
define('HEADING_SHIPPING_METHOD', 'Shipping Method');
define('HEADING_PRODUCTS', 'Products');
define('HEADING_TAX', 'Tax');
define('HEADING_TOTAL', 'Total');
define('HEADING_BILLING_INFORMATION', 'Billing Information');
define('HEADING_BILLING_ADDRESS', 'Billing Address');
define('HEADING_PAYMENT_METHOD', 'Payment Method');
define('HEADING_PAYMENT_INFORMATION', 'Payment Information');
define('HEADING_ORDER_COMMENTS', 'Comments About Your Order');
define('ERROR_PAYMENT_METHOD', 'Please chose a payment method.');
define('DEMO_USED_MESSAGE', 'Error : Sorry, You have already used free service.');
define('TABLE_HEADING_COMMENTS','Comment About your order');

define('TEXT_EDIT', 'Edit');
define('IMAGE_BUTTON_CONFIRM_ORDER', 'Confirm order');
define('IMAGE_BUTTON_BACK', 'Back');
define('IMAGE_BUTTON_PRINT', 'Print');
define('INFO_TEXT_SORRY_PROMOTION','Error : Sorry the Promotion code you have entered is not valid.');
define('INFO_TEXT_ALREADY_USED_CODE','Error : Sorry you have already used this code.');
define('INFO_TEXT_ACCEPT','Accept');
?>