<?
define('HEADING_TITLE','Gift');
define('INFO_TEXT_AMOUNT','Amount Due - %s');
define('IMAGE_BUTTON_NEXT','Next>>');
define('IMAGE_BUTTON_CHANGE_ORDER','Change Order');
?>