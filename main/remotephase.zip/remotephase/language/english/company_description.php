<?
define('HEADING_TITLE','Company description');
define('MESSAGE_SUCCESS_INSERTED','Success : Company description successfully inserted.');
define('MESSAGE_SUCCESS_UPDATED','Success : Company description successfully updated.');
define('IMAGE_INSERT','Insert');
define('IMAGE_UPDATE','Update');
define('IMAGE_PREVIEW','Preview');
define('IMAGE_BACK','Back');
?>