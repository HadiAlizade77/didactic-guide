<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', 'Your Account Has Been Created!');
define('TEXT_ACCOUNT_CREATED', 'Dear <b>%s</b>, Congratulations!<br><br> Your new account has been successfully created!<br><br> You can now take advantage of member privileges to enhance your online jobsite application experience with us. <br><br>If you have <b>any</b> questions about the operation of this online jobsite, please contact the '.stripslashes(CONTACT_ADMIN).'<br><br>A confirmation has been sent to the provided email address. If you have not received it within the hour, please contact the '.stripslashes(CONTACT_ADMIN).'.<br><br><b>Your user name :</b> %s<br><b>Your password : </b>xxxxxx <br><br>You can access our site by this user name and password.<br><b>'.tep_db_output(SITE_TITLE).'</b>');
define('IMAGE_BUTTON_NEXT', 'Next');
?>