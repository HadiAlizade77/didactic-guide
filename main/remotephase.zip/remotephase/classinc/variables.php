<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft Pvt. Ltd.   #**********
**********# Copyright (c) www.aynsoft.com 2005  #**********
**********************************************************/
$discount_type_array=array(array("id"=>"1","text"=>"One Free Registration"),
                     array("id"=>"2","text"=>"Percentage off Total"),
                     array("id"=>"3","text"=>"Dolllar Amount off Total"),
                    );
?>