<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft Pvt. Ltd.   #**********
**********# Copyright (c) www.aynsoft.com 2005  #**********
**********************************************************/
// configuration variables defined here
include_once(PATH_TO_MAIN_PHYSICAL_CLASS."configuration.php");
$obj_conf=new configuration();
?>