<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft Pvt. Ltd.   #**********
**********# Copyright (c) www.aynsoft.com 2005  #**********
**********************************************************/
/*
define('DB_SERVER', 'localhost');
define('DB_SERVER_USERNAME', 'root');
define('DB_SERVER_PASSWORD', '');
define('DB_DATABASE', 'remotephase');
define('USE_PCONNECT', 'false');
*/
//*
define('DB_SERVER', 'localhost');
define('DB_SERVER_USERNAME', 'dodnqvmy_jbsite');
define('DB_SERVER_PASSWORD', '~LdEOT0d@$EI');
define('DB_DATABASE', 'dodnqvmy_jbbord');
define('USE_PCONNECT', 'true');
//*/
?>