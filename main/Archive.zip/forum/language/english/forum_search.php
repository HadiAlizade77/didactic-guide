<?
define('HEADING_TITLE', 'Forum Search');
define('INFO_TEXT_HOME','Home');
define('INFO_TEXT_HEADING_SEAECH','Search');

define('TABLE_HEADING_TOPICS', 'Topics');
define('TABLE_HEADING_REPLIES', 'Replies');
define('TABLE_HEADING_AUTHOR', 'Author');
define('TABLE_HEADING_VIEW', 'Views');

define('INFO_TEXT_KEAYWORD','Keyword');
define('INFO_TEXT_KEYWORD_CRITERIA','Choose your search criteria :');
define('INFO_TEXT_KEYWORD_WORD1','any of these words');
define('INFO_TEXT_KEYWORD_WORD2','all of these words');
define('INFO_TEXT_SEARCH_WITHIN','Search Within :');
define('INFO_TEXT_SEARCH_CATEGORY','Category: ');
define('INFO_TEXT_SEARCH_FORUM','Search in Forum(s): ');
define('INFO_TEXT_FORUM_POSTED','Forum Posted :');
define('INFO_TEXT_SECURITY_CODE','Security Code :');
define('INFO_TEXT_TYPE_CODE','Type the code shown');

define('ENTRY_SECURITY_CODE_ERROR','Error: Invalid Security Code .');

define('IMAGE_SEARCH','Search');
?>