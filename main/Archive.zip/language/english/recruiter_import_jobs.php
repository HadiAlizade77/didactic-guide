<?
/*
***********************************************************
***********************************************************
**********#	Name				      : Shambhu Prasad Patnaik  		#***********
**********#	Company			    : Aynsoft							     #***********
**********#	Copyright (c) www.aynsoft.com 2004	#***********
***********************************************************
***********************************************************
*/
define('HEADING_TITLE','Import Multiple Jobs');
define('SECTION_INFO_TEXT_IMPORT','Import');
define('INFO_TEXT_IMPORT_FILE','Import File :');
define('INFO_TEXT_IMPORT_FILE2','Import .XML, .CSV  (Microsoft comma separate) ');
define('INFO_TEXT_SAMPLE_FILE','Download sample file :');
define('INFO_TEXT_SUCCESSFULLY_JOB','successfully job :');
define('INFO_TEXT_INSERTED','inserted.');
define('INFO_TEXT_IMPORT_MULTIPLE_JOBS','Import Multiple Jobs');
define('INFO_TEXT_TO_IMPORT_MULTIPLE_JOBS','To import multiple jobs from');
define('INFO_TEXT_SELECT_CSV_FILE','CSV (Comma separated values)Select the CSV file in your PC, from browse button and click on Import now button. Ensure that the format is uniform like:');
define('INFO_TEXT_SAMPLE_CSV_FILE','sample CSV file');
define('INFO_TEXT_SELECT_XML','XML file Select the XML file from your PC, from browse button and click on Import now button. Ensure that the format is uniform like:');
define('INFO_TEXT_SAMPLE_XML_FILE','sample XML file');
define('INFO_TEXT_SUBSEQUENTLY_THE_JOBS','Subsequently the jobs would be posted in the jobsite database and you can view in the');
define('INFO_TEXT_JOB_SEARCH_RESULTS','job search results');
define('INFO_TEXT_IMPORT','Import');
define('INFO_TEXT_FIELD_OVERVIEW','Field Overview');
define('INFO_TEXT_FIELD','Field');
define('INFO_TEXT_EXAMPLE','Example');
define('INFO_TEXT_NOTES','Notes');
define('INFO_TEXT_JOB_TITLE','job_title');
define('INFO_TEXT_PROGRAMMER','Programmer');
define('INFO_TEXT_FREE_TEXT','Free Text');
define('INFO_TEXT_JOB_REFERENCE','job_reference');
define('INFO_TEXT_RECRUITMENT','Reecuiterment 2009');
define('INFO_TEXT_FREE_TEXT_THE_REFERENCE','Freetext, the reference number assigned to the advert by the recruiter');
define('INFO_TEXT_JOB_COUNTRY','job_country');
define('INFO_TEXT_INDIA','India');
define('INFO_TEXT_FREE_TEXT_FROM_LIST_PROVIDED','Free Text,from list provided');
define('INFO_TEXT_JOB_STATE','job_state');
define('INFO_TEXT_DELHI','Delhi');
define('INFO_TEXT_JOB_LOCATION','job_location');
define('INFO_TEXT_JOB_NEW_DELHI','New Delhi');
define('INFO_TEXT_JOB_SALARY','job_salary');
define('INFO_TEXT_MONEY','Rs.50000');
define('INFO_TEXT_JOB_INDUSTRY','job_industry');
define('INFO_TEXT_IT_SOFTWARE','IT/Software,IT/Hardware');
define('INFO_TEXT_MAXIMUN_5','Free Text,from list provided(maximum 5)');
define('INFO_TEXT_JOB_SHORT_DESCRIPTION','job_short_description');
define('INFO_TEXT_SHORT_DESCRIPTION','Short description');
define('INFO_TEXT_200_LIMIT','Freetext, 200 char limit, detailed job short description');
define('INFO_TEXT_JOB_DESCRIPTION','job_description');
define('INFO_TEXT_DETAILED_DESCRIPTION','Detailed description');
define('INFO_TEXT_1000_LIMIT','Freetext, 1000 char limit, detailed job description');
define('INFO_TEXT_JOB_TYPE','job_type');
define('INFO_TEXT_CONTRACT_PERMANENT','Contract,Permanent');
define('INFO_TEXT_JOB_EXPERIENCE','job_experience');
define('INFO_TEXT_AN_INTEGER','An Integer. The number of month');
define('INFO_TEXT_JOB_DURATION','job_duration');
define('INFO_TEXT_AN_INTEGER_VALUE','An Integer. The number of days the advert should be live on the website.');
define('INFO_TEXT_XML_FILE_FORMAT','XML File Format');
define('INFO_TEXT_SEPARATED_BY','separate by "," and match in post job category');
define('INFO_TEXT_SEPARATED_BY_JOB_TYPE','separate by "," and match in post job type');
define('INFO_TEXT_NUMBER_OF_MONTHS','Number of Month');
define('INFO_TEXT_NUMBER_OF_DAYS','Number of day');
define('INFO_TEXT_CSV_FILE','CSV');
define('INFO_TEXT_XML','XML');
?>