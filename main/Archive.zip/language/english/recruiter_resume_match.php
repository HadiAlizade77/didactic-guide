<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/
define('HEADING_TITLE','Resume Match Level');

define('INFO_TEXT_FIELDS','Fields');
define('INFO_TEXT_JOB_WEIGHTS','Job Weights');
define('INFO_TEXT_RESUME_WEIGHTS','Resume Match');
define('INFO_TEXT_JOBSEEKER_APP_ID','Application Id :');
define('INFO_TEXT_LOCATION','Location');
define('INFO_TEXT_INDUSTRY','Industry ');
define('INFO_TEXT_JOB_TYPE','Job Type');
define('INFO_TEXT_EXPERIENCE','Experience');
define('INFO_TEXT_TOTAL','Total :');

define('ERROR_JOB_NOT_EXIST','Sorry this job does not exist.');
define('ERROR_RESUME_NOT_EXIST','Sorry this resume  does not exist.');
?>