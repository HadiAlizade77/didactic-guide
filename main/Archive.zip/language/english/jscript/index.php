<?
header("location:../");
exit;
?>