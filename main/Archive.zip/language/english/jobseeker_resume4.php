<?
define('HEADING_TITLE','Skills and Languages');

define('TABLE_HEADING_SKILL','Skill');
define('TABLE_HEADING_SKILL_LEVEL','Skill Level');
define('TABLE_HEADING_LAST_USED','Last Used');
define('TABLE_HEADING_YEARS_OF_EXP','Experience');


define('TABLE_HEADING_LANGUAGE','Language');
define('TABLE_HEADING_PROFICIENCY','Proficiency');


define('TABLE_HEADING_EDIT','Edit');
define('TABLE_HEADING_DELETE','Delete');

define('INFO_TEXT_EDIT','Edit');
define('INFO_TEXT_DELETE','Delete');

define('REQUIRED_INFO','* Required information');
define('SECTION_ACCOUNT_RESUME_NAME','Resume name');

define('SECTION_SKILLS','Skills');
define('SECTION_LANGUAGES','Languages');
define('SECTION_DOCUMENT_UPLOAD','Resume');

define('INFO_TEXT_RESUME_NAME','Resume name :');

define('INFO_TEXT_SKILL','Skill :');
define('INFO_TEXT_SKILL_LEVEL','Skill Level :');
define('INFO_TEXT_LAST_USED','Last Used :');
define('INFO_TEXT_YEARS_OF_EXP','Years of Experience :');

define('INFO_TEXT_LANGUAGE','Language :');
define('INFO_TEXT_PROFICIENCY','Proficiency :');

define('MESSAGE_SUCCESS_INSERTED','Success : Record successfully Inserted.');
define('MESSAGE_SUCCESS_UPDATED','Success : Record successfully Updated.');
define('MESSAGE_SUCCESS_DELETE','Success : Record successfully Deleted.');

define('IMAGE_SAVE_NEXT','Save & Goto Next Step');
define('IMAGE_RESET','Reset');
define('IMAGE_SAVE_ADD_NEW','Save');
define('IMAGE_GO_TO_RESUME_LIST','Go to Resume List');
define('IMAGE_NEXT','Next >>');
define('INFO_TEXT_PLEASE_SELECT','Please Select');
define('INFO_TEXT_RESUME_NAME','Resume Name :');
define('INFO_TEXT_OBJECTIVE','Objective');
define('INFO_TEXT_TARGET_JOB','Target Job');
define('INFO_TEXT_TOTAL_WORK_EXP','Total Work Experience');
define('INFO_TEXT_YOUR_WORK_EXPERIENCE','Work Experience');
define('INFO_TEXT_LIST_OF_REFERENCES','List of References');
define('INFO_TEXT_EDUCATION_DETAILS','Education Details');
define('INFO_TEXT_YOUR_SKILLS','Skills');
define('INFO_TEXT_LANGUAGES','Languages');
define('INFO_TEXT_RESUME','Resume');
define('INFO_TEXT_PERSONAL_PROFILE','Personal Profile');
define('INFO_TEXT_EXPERIENCE','Experience');
define('INFO_TEXT_LEFT_RESUME','General');
define('INFO_TEXT_LEFT_EXPERIENCE','Experience');
define('INFO_TEXT_LEFT_EDUCATION','Education');
define('INFO_TEXT_LEFT_SKILLS','Skills');
define('INFO_TEXT_LEFT_UPLOAD','Upload');
define('INFO_TEXT_LEFT_REFERENCE','References');
define('INFO_TEXT_LEFT_VIEW_RESUME','View Resume');
define('INFO_SKIP_THIS_STEP','Skip The Step');
?>