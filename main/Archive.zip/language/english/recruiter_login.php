<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Recruiter Login here');

define('INFO_TEXT_EMAIL_ADDRESS','E-Mail Address :');
define('INFO_TEXT_PASSWORD','Password :');

define('IMAGE_CONFIRM','Confirm');
define('AUTO_LOGIN','Enable Auto Log in');
define('SORRY_LOGIN_MATCH','Sorry your Email-address or password seems to be incorrect. Please try again.');
define('FACEBOOK_USER_JOBSEEKER_ERROE','Sorry your email-address Registe as jobseeker therefore not add as recruiter.');
define('INFO_TEXT_NEW_USER','New User?');
define('INFO_TEXT_CLICK_HERE','Click here');
define('INFO_TEXT_REGISTER_NOW','Register Now !');
define('INFO_TEXT_FORGOT_PASSWORD','Forgot Password');
define('INFO_TEXT_EMAIL_PASSWORD','we will email your password to you.');
define('INFO_TEXT_ALREADY_MEMBER','Already a Member?');
define('INFO_TEXT_LOGIN','Login');
define('INFO_TEXT_QUOT1','Post jobs by category');
define('INFO_TEXT_QUOT2','View,save &amp; organize resumes online');
define('INFO_TEXT_QUOT3','Get resumes via email as alert');
define('INFO_TEXT_QUOT4','Track applicants, filter and conduct selection process online');

?>