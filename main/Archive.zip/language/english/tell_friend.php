<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Tell to your friend');
define('SUCCESS_EMAIL_SENT','Your message successfully sent to your friend.');
define('INFO_TEXT_FROM_NAME','Your full name : ');
define('INFO_TEXT_FROM_EMAIL_ADDRESS','Your email-address : ');
define('INFO_TEXT_TO_NAME','Your friend\'s full name : ');
define('INFO_TEXT_TO_EMAIL_ADDRESS','Your friend\'s email-address : ');
define('INFO_TEXT_SUBJECT','Subject : ');
define('INFO_TEXT_MESSAGE','Message : ');
define('INFO_TEXT_SECURITY_CODE','Security Code :');
define('INFO_TEXT_TYPE_CODE','Type the code shown');
define('ERROR_SECURITY_CODE','Error: Invalid Security Code .');
define('IMAGE_SEND','Send');
define('INFO_TEXT_HI','Hi');
define('INFO_TEXT_YOUR_FRIEND','Your friend');
define('INFO_TEXT_HAS_SENT','has sent a message for you.');
define('INFO_TEXT_EMAIL_ADDRESS','E-mail Address is :');
define('INFO_TEXT_MESSAGE','Message is as follows...');
define('INFO_TEXT_TYPE_CODE','Type the code shown');

?>