<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Resume Statistics');
define('TABLE_HEADING_RESUME_NAME', 'Resume Name');
define('TABLE_HEADING_INSERTED', 'Viewed On');
define('TABLE_HEADING_COMPANY_NAME', 'Company name');
define('INFO_TEXT_STATISTICS','statistics');
define('INFO_TEXT_NO_STATISTICS_AVAILABLE','Sorry, Statistics not available.');
?>