<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', 'My Resume Search Agents');
//////////////////////////
define('TABLE_HEADING_RUN', 'Run');
define('TABLE_HEADING_EDIT','Edit');
define('TABLE_HEADING_DELETE','Delete');
define('TABLE_HEADING_INSERT_DATE', 'Inserted');
define('TABLE_HEADING_UPDATE_DATE', 'Updated');
define('TABLE_HEADING_TITLE_NAME', 'Title Name ');
define('MESSAGE_SUCCESS_DELETE','Success : resume search agent successfully deleted.');
define('MESSAGE_ERROR_RESUME_SEARCH_AGENT_NOT_EXIST','Error: Sorry, this ressume search agent does not exist.');
define('INFO_TEXT_YOU_HAVE','You have');
define('INFO_TEXT_RESUME_SEARCH_AGENTS','resume search agents.');
define('INFO_TEXT_NO_RESUME_SEARCH_AGENTS','No resume search agents found.');
define('INFO_TEXT_CREATE_NEW_RESUME_ALERT','Create New Resume Alert');
define('INFO_TEXT_GET_DAILY_RESUME','Get Daily Resume via email');

define('INFO_TEXT_RUN','Run');
define('INFO_TEXT_EDIT','Edit');
define('INFO_TEXT_DELETE','Delete');
?>