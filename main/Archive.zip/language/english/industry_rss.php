<?
define('HEADING_TITLE','RSS');
define('INFO_TEXT_ALL_JOB_RSS','All jobs RSS');
?>