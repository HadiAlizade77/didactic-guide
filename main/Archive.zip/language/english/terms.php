<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Terms & Conditions');
define('INFO_TEXT_CONTENT','
<P class=MsoNormal style="MARGIN: 0in 0in 0pt">Under construction</P>
');
?>