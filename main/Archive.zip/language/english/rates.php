<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Posting Plans - Rate Card');
define('TABLE_HEADING_PLAN_TYPE_NAME','Plan');
define('TABLE_HEADING_PLAN_TYPE_TIME_PERIOD','Time period');
define('TABLE_HEADING_PLAN_TYPE_FEE','Price');
define('TABLE_HEADING_PLAN_TYPE_NO_OF_JOBS','Jobs');
define('TABLE_HEADING_PLAN_TYPE_NO_OF_CVS','CV\'s');
define('TABLE_HEADING_PLAN_TYPE_NO_OF_SMS','SMS');
define('TABLE_HEADING_PLAN_TYPE_BUY','Buy');
define('INFO_TEXT_FREE_SERVICE','free service');
define('INFO_TEXT_UNLIMITED','Unlimited');
define('INFO_TEXT_QUOT1','Post your jobs and access resumes - Instantly.');
define('INFO_TEXT_QUOT2','These packages will help you hire the right person, right away. Select the plan you wish to buy:');
define('INFO_TEXT_POST_JOBS','Post Jobs');
define('INFO_TEXT_F_POST_JOBS','Post Featured Jobs');
define('INFO_TEXT_SEARCH_RESUMES','Search Resumes');
define('INFO_TEXT_POST_SEARCH','Post Jobs & Search Resumes');
define('INFO_TEXT_F_POST_SEARCH','Post Featured Jobs & Search Resumes');
define('INFO_TEXT_KEY_FEATURES','Key Features');
define('INFO_TEXT_POST_JOB_INSTANTLY','Post your job instantly');
define('INFO_TEXT_MANAGE_MONITOR','Manage and monitor results');
define('INFO_TEXT_TRACK_APPLICATION','Track applicants, filter and conduct selection process online');
define('INFO_TEXT_GET_RESUMES','Get resumes via email');
define('INFO_TEXT_SEARCH_QUALIFIED','Search high quality resumes through advance search engine');
define('INFO_TEXT_VIEW_SAVE_ORGANISATION','View, save & organize resumes online');
define('INFO_TEXT_GET_ACCESS_TO_RESUME','Get access to resume database instantly');
define('INFO_TEXT_USE_APPLICANT_TRACKING','Use Applicant Tracking System to shortlist candidates');
define('INFO_TEXT_FOR_OTHER_OPTIONS','For other options or clarifications, please.');
define('INFO_TEXT_CONTACT_US','contact us');
define('BUY_NOW','Buy Now');
?>