<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', 'List Of Direct Applicants');
define('TABLE_HEADING_JOB_TITLE','Job Title');

define('TABLE_HEADING_APPLICANTNL_NAME','Name');
define('TABLE_HEADING_APPLICANTNL_EMAIL_ADDRESS','Email address');
define('TABLE_HEADING_INSERTED','Inserted');
define('TABLE_HEADING_RESUME_DELETE','Delete');
define('TABLE_HEADING_RESUME_VIEW','View');

define('MESSAGE_SUCCESS_DELETED', 'Success : Resume successfully deleted.');
define('INFO_TEXT_RESUME','Resume');
define('INFO_TEXT_RESUMES','Resumes');
define('INFO_TEXT_HAS_SAVED','has saved');
define('INFO_TEXT_TO_YOUR_SEARCH_CRITERIA','to your search criteria.');
define('INFO_TEXT_HAS_NOT_SAVED','has not saved any resume to your search criteria.');
define('INFO_TEXT_ALL','All');
define('INFO_TEXT_LIST_OF_APPLICATIONS','List of Registered Applicants');

?>