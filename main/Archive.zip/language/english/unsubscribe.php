<?
define('SORRY_NO_EMAIL_ADDRESS_EXIST','Sorry your Email-address not exist.');
define('EMAIL_UNSUBSCRIBE_SUCCESS','Your are successfully unsubscribe newletter.');
define('ALL_READY_EMAIL_UNSUBSCRIBE','Your are already unsubscribe newletter.');
?>