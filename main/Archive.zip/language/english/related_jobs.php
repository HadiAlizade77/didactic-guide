<?
/**********************************************************
**********# Name      : Shambhu Prasad Patnaik  #**********
**********# Company   : Aynsoft                 #**********
**********# Copyright (c) www.aynsoft.com 2013  #**********
**********************************************************/

define('HEADING_TITLE','Related Jobs');
define('INFO_TEXT_EMAIL_THIS_JOB','Recommend to a Friend');
define('INFO_TEXT_APPLY_TO_THIS_JOB','Apply Job');
?>