<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE','Change your password');

define('INFO_TEXT_OLD_PASSWORD','Old Password :');
define('INFO_TEXT_NEW_PASSWORD','New Password :');
define('INFO_TEXT_CONFIRM_PASSWORD','Confirm Password :');

define('IMAGE_CONFIRM','Confirm');
define('AUTO_LOGIN','Enable Auto Log in');
define('SORRY_LOGIN_MATCH','Sorry your Email-address or password seems to be incorrect. Please try again.');
define('PASSWORD_MATCH_ERROR','Sorry your password & confirm password does not match.');
define('MIN_PASSWORD_ERROR','password must be atleast 5 characters');
define('MAX_PASSWORD_ERROR','password cannot be greater than 15 characters.');
?>