<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE1','Job Seeker');
define('AUTO_LOGIN1','Remember Me');
define('FACEBOOK_USER_RECRUITER_ERROE1','Sorry your email-address Registe as recruiter therefore not add as jobseeker.');
define('INFO_TEXT_FORGOT_PASSWORD1','Forgot your password?');
define('INFO_TEXT_NEW_USER1','Don\'t have an account?');
define('INFO_TEXT_REGISTER_NOW1','Register Now!');


define('HEADING_TITLE2','Employer');
define('AUTO_LOGIN2','Remember Me');
define('FACEBOOK_USER_JOBSEEKER_ERROE2','Sorry your email-address Registe as jobseeker therefore not add as recruiter.');
define('INFO_TEXT_NEW_USER2','Don\'t have an account?');
define('INFO_TEXT_REGISTER_NOW2','Register Now !');
define('INFO_TEXT_FORGOT_PASSWORD2','Forgot your password?');

define('SORRY_LOGIN_MATCH','Sorry your Email-address or password seems to be incorrect. Please try again.');
define('SIGN_IN','Sign in');
define('INTO_LOG_IN','Log In');
define('INFO_LOGIN_WITH','Or Login with');
define('INFO_NO_ACCOUNT','Don\'t have an account?');
?>