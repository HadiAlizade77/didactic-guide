<?
define('HEADING_TITLE','Invite Friend');
define('INFO_TEXT_EMAIL_ADDRESS','Email :');
define('INFO_TEXT_EMAIL_PASSWORD','Password :');
define('INFO_TEXT_EMAIL_PROVIDER','Provider :');
define('INFO_TEXT_EMAIL_PROVIDER_TEXT','Live/Hotmail,Gmail,Yahoo,Aol provider<br>enter full email address.');

define('TABLE_HEADING_FRIEND_NAME','Friend Name');
define('TABLE_HEADING_EMAIL_ADDRESS','Email Address');
define('TABLE_HEADING_INVITE','Invite ?');

define('EMAIL_ADDRESS_ERROR','Please enter email address.');
define('EMAIL_PASSWORD_ERROR','Please enter email password.');
define('EMAIL_PROVIDER_ERROR','Please enter email provider.');
define('INVALID_EMAIL_ADDRESS_ERROR','Your Email-Address is not valid.');
define('FULL_EMAIL_ADDRESS_ERROR','Please enter the full email, not just the username');
define('INVALID_INVITATION_LIST_ERROR','You haven\'t selected any contacts to invite');
define('FRIEND_NAME_ERROR','You haven\'t field  user "%s" name.');
define('FRIEND_EMAIL_ERROR','email address error.');

define('SUCCESS_SEND_INVITE_REQUEST','successfully send invitaion  request (%s).');
define('SUCCESS_SEND_FRIEND_REQUEST','successfully send friend  request (%s).');
define('INFO_TEXT_LOGIN_FAILED','Login failed. Please check the email and password you have provided and try again later');
define('INFO_TEXT_UNABLE_TO_GET_CONTACTS','Unable to get contacts.');
define('INFO_TEXT_INVITED_YOU','invited You to join in');
define('INFO_TEXT_CLICK_HERE','Click Here');
define('INFO_TEXT_CHECK_ALL','Check All');
define('INFO_TEXT_UNCHECK_ALL','Uncheck All');
define('INFO_TEXT_INVITE_YOUR_FRIENDS','Invite your friends and acquaintances to join you on this site');
define('INFO_TEXT_LIVE_HOTMAIL','Live/Hotmail,Gmail,Yahoo,Aol provider, enter full email address.');
define('INFO_TEXT_YOU_ALREADY','You may already have friends on');
define('INFO_TEXT_IF_YOU_LOG_INTO','If you log into your email account,');
define('INFO_TEXT_WE_COULD_FIND','we could find them for you.');
?>
