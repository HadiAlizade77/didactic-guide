<?
define('HEADING_TITLE','Private Notes');
?>