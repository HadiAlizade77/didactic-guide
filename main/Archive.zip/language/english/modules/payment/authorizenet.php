<?
 define('MODULE_PAYMENT_AUTHORIZENET_TEXT_TITLE', 'Authorize.net');
 //define('MODULE_PAYMENT_AUTHORIZENET_TEXT_TITLE', 'Authorize.net <img src="img/visa.gif" alt="Visa" align="absmiddle"><img src="img/mc.gif" alt="Master Card" align="absmiddle"><img src="img/discover.gif" alt="Discover" align="absmiddle"><img src="img/amex.gif" alt="American Express" align="absmiddle">');
 define('MODULE_PAYMENT_AUTHORIZENET_TEXT_DESCRIPTION', 'Authorize.net');
 define('MODULE_PAYMENT_AUTHORIZENET_TEXT_ERROR_MESSAGE', 'There has been an error processing your credit card. Please try again.');
 define('MODULE_PAYMENT_AUTHORIZENET_TEXT_DECLINED_MESSAGE', 'Your credit card was declined. Please try another card or contact your bank for more info.');
 define('MODULE_PAYMENT_AUTHORIZENET_TEXT_ERROR', 'Credit Card Error!');
?>
