<?
  define('MODULE_PAYMENT_MONEYORDER_TEXT_TITLE', 'Bank Transfer');
  define('MODULE_PAYMENT_MONEYORDER_TEXT_DESCRIPTION', 'Make Payable To:&nbsp;' . nl2br(MODULE_PAYMENT_MONEYORDER_PAYTO) . '<br><br>Send To:<br>' . nl2br(STORE_NAME_ADDRESS) . '<br><br>' . 'Your plan will not be activated until we receive payment.');
  define('MODULE_PAYMENT_MONEYORDER_TEXT_EMAIL_FOOTER', "Make Payable To: ". MODULE_PAYMENT_MONEYORDER_PAYTO . "\n\nSend To:\n" . STORE_NAME_ADDRESS . "\n\n" . 'Your plan will not be activated until we receive payment.');
?>
