<?
/**********************************************************
**********# Name          : Shambhu Prasad Patnaik  #**********
**********# Company       : Aynsoft             #**********
**********# Copyright (c) www.aynsoft.com 2004  #**********
**********************************************************/


define('HEADING_TITLE', 'My Saved Searches /Job Alert Agent');
//////////////////////////
define('TABLE_HEADING_RUN', 'Run');
define('TABLE_HEADING_EDIT', 'Edit');
define('TABLE_HEADING_DELETE', 'Delete');
define('TABLE_HEADING_INSERT_DATE', 'Inserted');
define('TABLE_HEADING_UPDATE_DATE', 'Updated');
define('TABLE_HEADING_TITLE_NAME', 'Title Name ');
define('MESSAGE_SUCCESS_DELETE','Success : Saved serach result successfully deleted.');
define('MESSAGE_JOB_ERROR','Sorry no job exists.');
define('MESSAGE_ERROR_SAVED_SERCH_NOT_EXIST','Error: Sorry, this saved searches does not exist.');
define('INFO_TEXT_YOU_HAVE','You have');
define('INFO_TEXT_SAVED_SEARCH','saved search results.');
define('INFO_TEXT_NO_SAVE_RESULT','No save result found.');
define('INFO_TEXT_CREATE_NEW_JOB_ALERT','Create New Job Alert');
define('INFO_TEXT_GET_DAILY_JOB_ALERTS','Get Daily Job Alerts Emailed to You');
define('INFO_TEXT_SAVE_SEARCH','Save Search :');
define('INFO_TEXT_JOB_SEARCH_CRITERIA','Job search criteria can be saved, so that you do not have to repeatedly select the criteria to run the same search.');
define('INFO_TEXT_JOB_ALERT','Job Alert :');
define('INFO_TEXT_WILL_SEND_EMAIL_NOTIFICATION','Will send you an email notification when new opportunities become available which match your interests.');

?>