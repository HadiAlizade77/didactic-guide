<?
define('HEADING_TITLE','Candidate Type');
define('INFO_TEXT_CANDIDATE_TYPE','Please select the the type :');
define('IMAGE_NEXT','Next >>');
define('FEATURED_MEMBER_ERROR','As you are already a featured member you cannot change your membership until the membership expires');
define('INFO_TEXT_FEATURED','Featured');
define('INFO_TEXT_REGULAR','Regular');
?>